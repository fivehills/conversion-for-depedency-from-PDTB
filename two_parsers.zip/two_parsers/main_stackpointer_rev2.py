import argparse
import os
import jsonlines
import numpy as np
import torch
import pyprind

import utils
import shared_functions
import parsers
import metrics


def main(args):
    ##################
    # Arguments
    ##################

    device = torch.device(f"cuda:{args.gpu}")
    config_name = args.config
    prefix = args.prefix
    actiontype = args.actiontype

    if prefix is None or prefix == "None":
        prefix = utils.get_current_time()

    assert actiontype in ["train", "evaluate"]

    ##################
    # Config
    ##################

    config = utils.get_hocon_config(config_path="./config/main.conf", config_name=config_name)
    sw = utils.StopWatch()
    sw.start("main")

    ##################
    # Paths
    ##################

    base_dir = "discourse_dep.%s" % config_name

    utils.mkdir(os.path.join(config["results"], base_dir))

    # Log file
    path_log = None
    if actiontype == "train":
        path_log = os.path.join(config["results"], base_dir, prefix + ".training.log")
    elif actiontype == "evaluate":
        path_log = os.path.join(config["results"], base_dir, prefix + ".evaluation.log")

    # Training loss and etc.
    path_train_losses = os.path.join(config["results"], base_dir, prefix + ".train.losses.jsonl")

    # Model snapshot
    path_snapshot = os.path.join(config["results"], base_dir, prefix + ".model")

    # Validation outputs and scores
    path_dev_pred = os.path.join(config["results"], base_dir, prefix + ".dev.pred.arcs")
    path_dev_eval = os.path.join(config["results"], base_dir, prefix + ".dev.eval.jsonl")

    # Evaluation outputs and scores
    path_test_pred = os.path.join(config["results"], base_dir, prefix + ".test.pred.arcs")
    path_test_eval = os.path.join(config["results"], base_dir, prefix + ".test.eval.json")

    # Gold data for validation and evaluation
    if config["dataset_name"] == "rstdt":
        path_dev_gold = os.path.join(config["caches-discourse-dep"], "rstdt.dev.gold.arcs")
        path_test_gold = os.path.join(config["caches-discourse-dep"], "rstdt.test.gold.arcs")
    elif config["dataset_name"] == "scidtb":
        path_dev_gold = os.path.join(config["caches-discourse-dep"], "scidtb.dev.gold.arcs")
        path_test_gold = os.path.join(config["caches-discourse-dep"], "scidtb.test.gold.arcs")
    elif config["dataset_name"] == "stac":
        path_dev_gold = os.path.join(config["caches-discourse-dep"], "stac.dev.gold.arcs")
        path_test_gold = os.path.join(config["caches-discourse-dep"], "stac.test.gold.arcs")
    elif config["dataset_name"] == "molweni":
        path_dev_gold = os.path.join(config["caches-discourse-dep"], "molweni.dev.gold.arcs")
        path_test_gold = os.path.join(config["caches-discourse-dep"], "molweni.test.gold.arcs")
    else:
        raise Exception("Dataset not supported.")

    utils.set_logger(path_log)

    utils.writelog("device: %s" % device)
    utils.writelog("config_name: %s" % config_name)
    utils.writelog("prefix: %s" % prefix)
    utils.writelog("actiontype: %s" % actiontype)

    utils.writelog(utils.pretty_format_dict(config))

    utils.writelog("path_log: %s" % path_log)
    utils.writelog("path_train_losses: %s" % path_train_losses)
    utils.writelog("path_snapshot: %s" % path_snapshot)
    utils.writelog("path_dev_pred: %s" % path_dev_pred)
    utils.writelog("path_dev_gold: %s" % path_dev_gold)
    utils.writelog("path_dev_eval: %s" % path_dev_eval)
    utils.writelog("path_test_pred: %s" % path_test_pred)
    utils.writelog("path_test_gold: %s" % path_test_gold)
    utils.writelog("path_test_eval: %s" % path_test_eval)

    ##################
    # Datasets
    ##################

    sw.start("data")

    if config["dataset_name"] == "rstdt":
        train_dataset = np.load(os.path.join(config["caches-discourse-dep"], "rstdt.train.npy"), allow_pickle=True)
        test_dataset = np.load(os.path.join(config["caches-discourse-dep"], "rstdt.test.npy"), allow_pickle=True)
        train_dataset, dev_dataset = shared_functions.generate_rstdt_dev_set(train_dataset=train_dataset,
                                                                             n_dev=30, seed=7777,
                                                                             output_path=path_dev_gold)
    elif config["dataset_name"] == "scidtb":
        train_dataset = np.load(os.path.join(config["caches-discourse-dep"], "scidtb.train.npy"), allow_pickle=True)
        dev_dataset = np.load(os.path.join(config["caches-discourse-dep"], "scidtb.dev.npy"), allow_pickle=True)
        test_dataset = np.load(os.path.join(config["caches-discourse-dep"], "scidtb.test.npy"), allow_pickle=True)
    elif config["dataset_name"] == "stac":
        train_dataset = np.load(os.path.join(config["caches-discourse-dep"], "stac.train.npy"), allow_pickle=True)
        dev_dataset = np.load(os.path.join(config["caches-discourse-dep"], "stac.dev.npy"), allow_pickle=True)
        test_dataset = np.load(os.path.join(config["caches-discourse-dep"], "stac.test.npy"), allow_pickle=True)
    elif config["dataset_name"] == "molweni":
        train_dataset = np.load(os.path.join(config["caches-discourse-dep"], "molweni.train.npy"), allow_pickle=True)
        dev_dataset = np.load(os.path.join(config["caches-discourse-dep"], "molweni.dev.npy"), allow_pickle=True)
        test_dataset = np.load(os.path.join(config["caches-discourse-dep"], "molweni.test.npy"), allow_pickle=True)
    else:
        raise Exception("Dataset not supported.")

    utils.writelog("Number of training data: %d" % len(train_dataset))
    utils.writelog("Number of development data: %d" % len(dev_dataset))
    utils.writelog("Number of test data: %d" % len(test_dataset))

    sw.stop("data")
    utils.writelog("Loaded the corpus. %f sec." % sw.get_time("data"))

    ##################
    # Parser
    ##################

    parser = parsers.StackPointerParser(device=device, config=config)

    # Load pre-trained parameters
    if actiontype != "train":
        parser.load_model(path=path_snapshot)
        utils.writelog("Loaded model from %s" % path_snapshot)

    parser.to_gpu(device=device)

    ##################
    # Action
    ##################

    if actiontype == "train":
        train(
            config=config,
            parser=parser,
            train_dataset=train_dataset,
            dev_dataset=dev_dataset,
            path_train_losses=path_train_losses,
            path_snapshot=path_snapshot,
            path_dev_pred=path_dev_pred,
            path_dev_gold=path_dev_gold,
            path_dev_eval=path_dev_eval)

    elif actiontype == "evaluate":
        with torch.no_grad():
            parse(
                parser=parser,
                dataset=test_dataset,
                path_pred=path_test_pred)
            scores = metrics.attachment_scores(
                pred_path=path_test_pred,
                gold_path=path_test_gold)
            scores["LAS"] *= 100.0
            scores["UAS"] *= 100.0
            scores["UUAS"] *= 100.0
            scores["RA"] *= 100.0
            utils.write_json(path_test_eval, scores)
            utils.writelog(utils.pretty_format_dict(scores))
            shared_functions.save_prediction_as_discourse_dep_format(dataset=test_dataset, path_pred=path_test_pred)

    utils.writelog("path_log: %s" % path_log)
    utils.writelog("path_train_losses: %s" % path_train_losses)
    utils.writelog("path_snapshot: %s" % path_snapshot)
    utils.writelog("path_dev_pred: %s" % path_dev_pred)
    utils.writelog("path_dev_gold: %s" % path_dev_gold)
    utils.writelog("path_dev_eval: %s" % path_dev_eval)
    utils.writelog("path_test_pred: %s" % path_test_pred)
    utils.writelog("path_test_gold: %s" % path_test_gold)
    utils.writelog("path_test_eval: %s" % path_test_eval)
    utils.writelog("Done.")
    sw.stop("main")
    utils.writelog("Time: %f min." % sw.get_time("main", minute=True))


####################################
# Training
####################################


def train(config,
          parser,
          train_dataset,
          dev_dataset,
          path_train_losses,
          path_snapshot,
          path_dev_pred,
          path_dev_gold,
          path_dev_eval):
    """
    Parameters
    -----------
    config: ConfigTree
    parser: StackPointerParser
    train_dataset: numpy.ndarray
    dev_dataset: numpy.ndarray
    path_train_losses: str
    path_snapshot: str
    path_dev_pred: str
    path_dev_gold: str
    path_dev_eval: str
    """
    # Get optimizer and scheduler
    n_train = len(train_dataset)
    max_epoch = config["max_epoch"]
    batch_size = config["batch_size"]
    total_update_steps = n_train * max_epoch // batch_size
    warmup_steps = int(total_update_steps * config["warmup_ratio"])

    optimizer = shared_functions.get_optimizer(model=parser.model, config=config)
    scheduler = shared_functions.get_scheduler(optimizer=optimizer, total_update_steps=total_update_steps,
                                               warmup_steps=warmup_steps)

    utils.writelog("*********************Training***********************")
    utils.writelog("n_train: %d" % n_train)
    utils.writelog("max_epoch: %d" % max_epoch)
    utils.writelog("batch_size: %d" % batch_size)
    utils.writelog("total_update_steps: %d" % total_update_steps)
    utils.writelog("warmup_steps: %d" % warmup_steps)

    writer_train = jsonlines.Writer(open(path_train_losses, "w"), flush=True)
    writer_dev = jsonlines.Writer(open(path_dev_eval, "w"), flush=True)
    bestscore_holder = utils.BestScoreHolder(scale=1.0)
    bestscore_holder.init()
    step = 0
    bert_param, task_param = parser.model.get_params()

    ##################
    # Initial validation phase
    ##################

    with torch.no_grad():
        parse(
            parser=parser,
            dataset=dev_dataset,
            path_pred=path_dev_pred)
        scores = metrics.attachment_scores(
            pred_path=path_dev_pred,
            gold_path=path_dev_gold)
        scores["LAS"] *= 100.0
        scores["UAS"] *= 100.0
        scores["UUAS"] *= 100.0
        scores["RA"] *= 100.0
        scores["epoch"] = 0
        writer_dev.write(scores)
        utils.writelog(utils.pretty_format_dict(scores))

    bestscore_holder.compare_scores(scores["LAS"], 0)

    # Save the model
    parser.save_model(path=path_snapshot)
    utils.writelog("Saved model to %s" % path_snapshot)

    ##################
    # /Initial validation phase
    ##################

    ##################
    # Training-and-validation loops
    ##################

    for epoch in range(1, max_epoch + 1):

        ##################
        # Training phase
        ##################

        perm = np.random.permutation(n_train)

        for instance_i in range(0, n_train, batch_size):

            ##################
            # Mini batch
            ##################

            # Initialize losses
            loss_attachment = 0.0
            acc_attachment = 0.0
            actual_batchsize = 0

            for data in train_dataset[perm[instance_i:instance_i + batch_size]]:

                ##################
                # One data
                ##################

                # Forward and compute losses
                one_loss_attachment, one_acc_attachment = parser.compute_loss(data=data)

                # Accumulate the losses
                loss_attachment += one_loss_attachment
                acc_attachment += one_acc_attachment
                actual_batchsize += 1

                ##################
                # /One data
                ##################

            # Average the losses
            actual_batchsize = float(actual_batchsize)
            loss_attachment /= actual_batchsize
            acc_attachment /= actual_batchsize

            # Merge the losses
            loss = loss_attachment

            # Backward
            parser.model.zero_grad()
            loss.backward()

            # Update
            if config["max_grad_norm"] > 0:
                torch.nn.utils.clip_grad_norm_(bert_param, config["max_grad_norm"])
                torch.nn.utils.clip_grad_norm_(task_param, config["max_grad_norm"])
            optimizer.step()
            scheduler.step()

            step += 1

            # Write log
            loss_attachment_data = float(loss_attachment.cpu())
            out = {"step": step,
                   "epoch": epoch,
                   "progress": "%d/%d" % (instance_i + actual_batchsize, n_train),
                   "progress_ratio": float(instance_i + actual_batchsize) / n_train * 100.0,
                   "attachment_loss": loss_attachment_data,
                   "attachment_accuracy": acc_attachment * 100.0,
                   "max_valid_las": bestscore_holder.best_score,
                   "patience": bestscore_holder.patience}
            writer_train.write(out)
            utils.writelog(utils.pretty_format_dict(out))

            ##################
            # /Mini batch
            ##################

        ##################
        # /Training phase
        ##################

        ##################
        # Validation phase
        ##################

        with torch.no_grad():
            parse(
                parser=parser,
                dataset=dev_dataset,
                path_pred=path_dev_pred)
            scores = metrics.attachment_scores(
                pred_path=path_dev_pred,
                gold_path=path_dev_gold)
            scores["LAS"] *= 100.0
            scores["UAS"] *= 100.0
            scores["UUAS"] *= 100.0
            scores["RA"] *= 100.0
            scores["epoch"] = epoch
            writer_dev.write(scores)
            utils.writelog(utils.pretty_format_dict(scores))

        did_update = bestscore_holder.compare_scores(scores["LAS"], epoch)
        utils.writelog("[Step %d] Max validation LAS: %f" % (step, bestscore_holder.best_score))

        # Save the model?
        if did_update:
            parser.save_model(path=path_snapshot)
            utils.writelog("Saved model to %s" % path_snapshot)

        ##################
        # /Validation phase
        ##################

    ##################
    # /Training-and-validation loops
    ##################

    writer_train.close()
    writer_dev.close()


####################################
# Evaluation
####################################


def parse(parser, dataset, path_pred):
    """
    Parameters
    ----------
    parser: StackPointerParser
    dataset: numpy.ndarray
    path_pred: str
    """
    sw = utils.StopWatch()
    sw.start()

    with open(path_pred, "w") as f:
        for data in pyprind.prog_bar(dataset):
            # Forward and parse
            labeled_arcs = parser.parse(data=data)

            # Write
            labeled_arcs = ["%s-%s-%s" % (x[0], x[1], x[2]) for x in labeled_arcs]
            f.write("%s\n" % " ".join(labeled_arcs))

    sw.stop()
    speed = float(len(dataset)) / sw.get_time()
    utils.writelog("Parsed %d documents; Time: %f sec.; Speed: %f docs/sec." % (len(dataset), sw.get_time(), speed))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--prefix", type=str, default=None)
    parser.add_argument("--actiontype", type=str, required=True)
    args = parser.parse_args()
    try:
        main(args)
    except Exception as e:
        utils.logger.error(e, exc_info=True)


###Please note that the modifications I made assume that the StackPointerParser class has been modified to focus solely on parsing discourse dependency relations, without considering the dependency tree task. If the StackPointerParser class still contains code related to the dependency tree task, you will need to modify it accordingly.

#The modifications I made include:

#Training Phase Modifications:

#The variable loss_relation and acc_relation are removed since we are not considering the dependency tree task.
#The calculation of average losses and accuracies is updated to only consider the attachment task.
#The line loss = loss_attachment + loss_relation is modified to loss = loss_attachment since we are not considering the relation task.
#The line loss.backward() and optimizer.step() are moved outside the loop over instances, as we only need to perform these operations once per batch.
#Validation Phase Modifications:

#The calculation of scores is still performed using the metrics.attachment_scores function, but the scores related to the relation task are not used or recorded.
#Parsing Modifications:

#The parse function is updated to only parse and write the discourse dependency relations (labeled arcs) to the output file. The calculation of the dependency tree and related operations are removed.
#These modifications ensure that the code focuses solely on parsing discourse dependency relations without considering the dependency tree task.
